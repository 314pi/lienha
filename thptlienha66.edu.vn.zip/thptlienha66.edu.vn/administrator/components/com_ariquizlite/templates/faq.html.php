<?php
	defined('ARI_FRAMEWORK_LOADED') or die('Direct Access to this location is not allowed.');
?>
<table class="adminlist">
	<tr>
		<td align="left">
			<?php AriQuizWebHelper::displayResValue('RichText.FAQ', false); ?>		
		</td>
	</tr>
</table>