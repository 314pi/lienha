<?php
define('ARI_I18N_CACHE_TEMPLATE', "<?php\r\nif (!isset(\$GLOBALS['%1\$s'])) \$GLOBALS['%1\$s'] = array();\$GLOBALS['%1\$s']['%2\$s'] = %3\$s;\r\n?>");
define('ARI_I18N_TEMPLATE_XML', '<?xml version="1.0" encoding="UTF-8"?>');
?>